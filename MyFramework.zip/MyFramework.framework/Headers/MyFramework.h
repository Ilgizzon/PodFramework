//
//  MyFramework.h
//  MyFramework
//
//  Created by Ilgiz Fazlyev on 13.04.2020.
//  Copyright © 2020 Ilgiz Fazlyev. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MyFramework.
FOUNDATION_EXPORT double MyFrameworkVersionNumber;

//! Project version string for MyFramework.
FOUNDATION_EXPORT const unsigned char MyFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyFramework/PublicHeader.h>


